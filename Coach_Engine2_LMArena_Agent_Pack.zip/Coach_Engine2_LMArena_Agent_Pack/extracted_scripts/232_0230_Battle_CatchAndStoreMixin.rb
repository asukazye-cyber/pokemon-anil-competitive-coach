module Battle::CatchAndStoreMixin
  #=============================================================================
  # Store caught Pokémon
  #=============================================================================
  def pbStorePokemon(pkmn)
    # Nickname the Pokémon (unless it's a Shadow Pokémon)
    if !pkmn.shadowPokemon?
      if $PokemonSystem.givenicknames == 0 &&
         pbDisplayConfirm(_INTL("¿Quieres ponerle un mote a {1}?", pkmn.name))
        nickname = @scene.pbNameEntry(_INTL("¿Mote de {1}?", pkmn.speciesName), pkmn)
        pkmn.name = nickname
      end
    end
    
    # Store the Pokémon
    active_quest_partner_name = nil
    active_quest_partner_idx = nil
    # ⚠️ ESTE RAMO NUNCA CORRE, E E DE PROPOSITO.
    #
    # O plugin `[v21.1 Hotfixes] Battle bug fixes.rb` REDEFINE o pbStorePokemon
    # de raiz — sem alias, linha 317 — e os plugins carregam depois de todos os
    # scripts. Logo esta versao do metodo e substituida inteira antes de o jogo
    # comecar, e o menu daqui nunca chegou a aparecer uma unica vez.
    #
    # A entrega ao NPC passou para um gancho no MOD 155, que envolve o metodo
    # FINAL seja ele de quem for. Deixa-se isto desligado em vez de apagado
    # porque documenta a armadilha; ligar aqui nao serve de nada.
    # Ver 155_NPC_Ajuda_Captura.rb e [[gancho-captura-plugin-clobber]].
    if false && defined?(GlobalNPC_Manager)
      GlobalNPC_Manager::NPC_CONFIG.each do |idx, config|
        npc_state = GlobalNPC_Manager.pbGetNPCLifeSystemData[idx]
        next if !npc_state
        state = npc_state[:capture_quest_state]
        if state && state != :completed && state != :not_started && state != :refused
          next if GlobalNPC_Manager.respond_to?(:aceita_especie?) &&
                  !GlobalNPC_Manager.aceita_especie?(idx, pkmn.species)
          active_quest_partner_name = config[:trainer_name]
          active_quest_partner_idx = idx
          break
        end
      end
    end

    if active_quest_partner_name
      cmds = []
      cmds << _INTL("Añadir al equipo")
      cmds << _INTL("Enviarlo al PC")
      cmds << _INTL("Ver los datos de {1}", pkmn.name)
      cmds << _INTL("Comprobar equipo") if pbPlayer.party_full?
      cmds << _INTL("Dar para {1}", active_quest_partner_name)
      
      loop do
        cmd = pbShowCommands(_INTL("¿Qué quieres hacer con {1}?", pkmn.name), cmds, 99)
        break if cmd == 99 # Cancelling = send to a Box (default behavior)
        
        is_give_npc = (cmd == cmds.length - 1)
        is_check_party = (pbPlayer.party_full? && cmd == 3)
        is_summary = (cmd == 2)
        is_send_to_pc = (cmd == 1)
        is_add_to_party = (cmd == 0)
        
        if is_give_npc
          pbDisplayPaused(_INTL("Você entregou {1} para {2}!", pkmn.name, active_quest_partner_name))
          if defined?(GlobalNPC_Manager)
            npc_state = GlobalNPC_Manager.pbGetNPCLifeSystemData[active_quest_partner_idx]
            if npc_state
              npc_state[:capture_quest_state] = :success_pending
              npc_state[:quest_captured_species] = pkmn.species
            end
          end
          pbDeregisterPartner rescue nil
          return
        elsif is_summary
          pbFadeOutIn do
            summary_scene = PokemonSummary_Scene.new
            summary_screen = PokemonSummaryScreen.new(summary_scene, true)
            summary_screen.pbStartScreen([pkmn], 0)
          end
        elsif is_check_party
          @scene.pbPartyScreen(0, true, 2)
        elsif is_send_to_pc
          stored_box = @peer.pbStorePokemon(pbPlayer, pkmn)
          box_name = @peer.pbBoxName(stored_box)
          if pkmn.item && pbConfirmMessage(_INTL("{1} tiene equipado {2}. ¿Quieres guardar el objeto en la mochila?", pkmn.name, pkmn.item.name))
            item = pkmn.item
            $bag.add(item)
            pkmn.item = nil
          end
          pbDisplayPaused(_INTL("¡{1} se ha enviado a la Caja \"{2}\"!", pkmn.name, box_name))
          return
        elsif is_add_to_party
          if pbPlayer.party_full?
            pbDisplay(_INTL("Elige un Pokémon de tu equipo para reemplazarlo."))
            party_index = -1
            @scene.pbPartyScreen(0, true, 1) do |idxParty, _partyScene|
              party_index = idxParty
              next true
            end
            next if party_index < 0 # Cancelled
            
            party_size = pbPlayer.party.length
            send_pkmn = pbPlayer.party[party_index]
            send_pkmn.makeUnmega
            send_pkmn.makeUnprimal
            @peer.pbOnLeavingBattle(self, send_pkmn, @usedInBattle[0][party_index], true)
            send_pkmn.statusCount = 0 if send_pkmn.status == :POISON
            
            stored_box = @peer.pbStorePokemon(pbPlayer, send_pkmn)
            pbPlayer.party.delete_at(party_index)
            box_name = @peer.pbBoxName(stored_box)
            if send_pkmn.item && pbConfirmMessage(_INTL("{1} tiene equipado {2}. ¿Quieres guardar el objeto en la mochila?", send_pkmn.name, send_pkmn.item.name))
              item = send_pkmn.item
              $bag.add(item)
              send_pkmn.item = nil
            end
            pbDisplayPaused(_INTL("Has enviado a {1} a la Caja \"{2}\".", send_pkmn.name, box_name))
            
            (party_index...party_size).each do |idx|
              if idx < party_size - 1
                @initialItems[0][idx] = @initialItems[0][idx + 1]
                $game_temp.party_levels_before_battle[idx] = $game_temp.party_levels_before_battle[idx + 1]
                $game_temp.party_critical_hits_dealt[idx] = $game_temp.party_critical_hits_dealt[idx + 1]
                $game_temp.party_direct_damage_taken[idx] = $game_temp.party_direct_damage_taken[idx + 1]
              else
                @initialItems[0][idx] = nil
                $game_temp.party_levels_before_battle[idx] = nil
                $game_temp.party_critical_hits_dealt[idx] = nil
                $game_temp.party_direct_damage_taken[idx] = nil
              end
            end
            
            pbPlayer.party << pkmn
            pbDisplayPaused(_INTL("{1} se ha añadido a tu equipo.", pkmn.name))
            return
          else
            stored_box = @peer.pbStorePokemon(pbPlayer, pkmn)
            pbDisplayPaused(_INTL("{1} se ha añadido a tu equipo.", pkmn.name))
            @initialItems[0][pbPlayer.party.length - 1] = pkmn.item_id if @initialItems
            return
          end
        end
      end
    end

    if pbPlayer.party_full? && (@sendToBoxes == 0 || @sendToBoxes == 2)   # Ask/must add to party
      cmds = [_INTL("Añadir al equipo"),
              _INTL("Enviarlo al PC"),
              _INTL("Ver los datos de {1}", pkmn.name),
              _INTL("Comprobar equipo")]
      cmds.delete_at(1) if @sendToBoxes == 2
      loop do
        cmd = pbShowCommands(_INTL("¿Qué quieres hacer con {1}?", pkmn.name), cmds, 99)
        next if cmd == 99 && @sendToBoxes == 2   # Can't cancel if must add to party
        break if cmd == 99   # Cancelling = send to a Box
        cmd += 1 if cmd >= 1 && @sendToBoxes == 2
        case cmd
        when 0   # Add to your party
          pbDisplay(_INTL("Elige un Pokémon de tu equipo para reemplazarlo."))
          party_index = -1
          @scene.pbPartyScreen(0, (@sendToBoxes != 2), 1) do |idxParty, _partyScene|
            party_index = idxParty
            next true
          end
          next if party_index < 0   # Cancelled
          party_size = pbPlayer.party.length
          # Get chosen Pokémon and clear battle-related conditions
          send_pkmn = pbPlayer.party[party_index]
          send_pkmn.makeUnmega
          send_pkmn.makeUnprimal
          @peer.pbOnLeavingBattle(self, send_pkmn, @usedInBattle[0][party_index], true)
          send_pkmn.statusCount = 0 if send_pkmn.status == :POISON   # Bad poison becomes regular
          # Send chosen Pokémon to storage
          send_pkmn = pbPlayer.party[party_index]
          stored_box = @peer.pbStorePokemon(pbPlayer, send_pkmn)
          pbPlayer.party.delete_at(party_index)
          box_name = @peer.pbBoxName(stored_box)
          if send_pkmn.item && pbConfirmMessage(_INTL("{1} tiene equipado {2}. ¿Quieres guardar el objeto en la mochila?", send_pkmn.name, send_pkmn.item.name))
            item = send_pkmn.item
            $bag.add(item)
            send_pkmn.item = nil
          end
          pbDisplayPaused(_INTL("Has enviado a {1} a la Caja \"{2}\".", send_pkmn.name, box_name))
          # Rearrange all remembered properties of party Pokémon
          (party_index...party_size).each do |idx|
            if idx < party_size - 1
              @initialItems[0][idx] = @initialItems[0][idx + 1]
              $game_temp.party_levels_before_battle[idx] = $game_temp.party_levels_before_battle[idx + 1]
              $game_temp.party_critical_hits_dealt[idx] = $game_temp.party_critical_hits_dealt[idx + 1]
              $game_temp.party_direct_damage_taken[idx] = $game_temp.party_direct_damage_taken[idx + 1]
            else
              @initialItems[0][idx] = nil
              $game_temp.party_levels_before_battle[idx] = nil
              $game_temp.party_critical_hits_dealt[idx] = nil
              $game_temp.party_direct_damage_taken[idx] = nil
            end
          end
          break
        when 1   # Send to a Box
          break
        when 2   # See X's summary
          pbFadeOutIn do
            summary_scene = PokemonSummary_Scene.new
            summary_screen = PokemonSummaryScreen.new(summary_scene, true)
            summary_screen.pbStartScreen([pkmn], 0)
          end
        when 3   # Check party
          @scene.pbPartyScreen(0, true, 2)
        end
      end
    end
    # Store as normal (add to party if there's space, or send to a Box if not)
    stored_box = @peer.pbStorePokemon(pbPlayer, pkmn)
    if stored_box < 0
      pbDisplayPaused(_INTL("{1} se ha añadido a tu equipo.", pkmn.name))
      @initialItems[0][pbPlayer.party.length - 1] = pkmn.item_id if @initialItems
      return
    end
    # Messages saying the Pokémon was stored in a PC box
    box_name = @peer.pbBoxName(stored_box)
    if pkmn.item && pbConfirmMessage(_INTL("{1} tiene equipado {2}. ¿Quieres guardar el objeto en la mochila?", pkmn.name, pkmn.item.name))
      item = pkmn.item
      $bag.add(item)
      pkmn.item = nil
    end
    pbDisplayPaused(_INTL("¡{1} se ha enviado a la Caja \"{2}\"!", pkmn.name, box_name))
  end

  # Register all caught Pokémon in the Pokédex, and store them.
  def pbRecordAndStoreCaughtPokemon
    @caughtPokemon.each do |pkmn|
      pbSetCaught(pkmn)
      pbSetSeen(pkmn)   # In case the form changed upon leaving battle
      # Record the Pokémon's species as owned in the Pokédex
      if !pbPlayer.owned?(pkmn.species)
        pbPlayer.pokedex.set_owned(pkmn.species)
        if $player.has_pokedex && $player.pokedex.species_in_unlocked_dex?(pkmn.species)
          pbDisplayPaused(_INTL("Los datos de {1} se han añadido a la Pokédex.", pkmn.name))
          pbPlayer.pokedex.register_last_seen(pkmn)
          @scene.pbShowPokedex(pkmn.species)
        end
      end
      # Record a Shadow Pokémon's species as having been caught
      pbPlayer.pokedex.set_shadow_pokemon_owned(pkmn.species) if pkmn.shadowPokemon?
      # Store caught Pokémon
      pbStorePokemon(pkmn)
    end
    @caughtPokemon.clear
  end

  #=============================================================================
  # Throw a Poké Ball
  #=============================================================================
  def pbThrowPokeBall(idxBattler, ball, catch_rate = nil, showPlayer = false)
    # Determine which Pokémon you're throwing the Poké Ball at
    battler = nil
    if opposes?(idxBattler)
      battler = @battlers[idxBattler]
    else
      battler = @battlers[idxBattler].pbDirectOpposing(true)
    end
    battler = battler.allAllies[0] if battler.fainted?
    # Messages
    itemName = GameData::Item.get(ball).name
    if battler.fainted?
      if itemName.starts_with_vowel?
        pbDisplay(_INTL("¡{1} lanzó un {2}!", pbPlayer.name, itemName))
      else
        pbDisplay(_INTL("¡{1} lanzó una {2}!", pbPlayer.name, itemName))
      end
      pbDisplay(_INTL("Pero no había objetivo..."))
      return
    end
    if itemName.starts_with_vowel?
      pbDisplayBrief(_INTL("¡{1} lanzó {2}!", pbPlayer.name, itemName))
    else
      pbDisplayBrief(_INTL("¡{1} lanzó {2}!", pbPlayer.name, itemName))
    end
    # Animation of opposing trainer blocking Poké Balls (unless it's a Snag Ball
    # at a Shadow Pokémon)
    if trainerBattle? && !(GameData::Item.get(ball).is_snag_ball? && battler.shadowPokemon?)
      @scene.pbThrowAndDeflect(ball, 1)
      pbDisplay(_INTL("¡El Entrenador bloqueó tu Ball! ¡Robar está mal!"))
      return
    end
    # Calculate the number of shakes (4=capture)
    pkmn = battler.pokemon
    @criticalCapture = false
    numShakes = pbCaptureCalc(pkmn, battler, catch_rate, ball)
    PBDebug.log("[Threw Poké Ball] #{itemName}, #{numShakes} shakes (4=capture)")
    # Animation of Ball throw, absorb, shake and capture/burst out
    @scene.pbThrow(ball, numShakes, @criticalCapture, battler.index, showPlayer)
    # Outcome message
    case numShakes
    when 0
      pbDisplay(_INTL("¡Oh, no! ¡El Pokémon se ha escapado!"))
      Battle::PokeBallEffects.onFailCatch(ball, self, battler)
    when 1
      pbDisplay(_INTL("¡Vaya! ¡Parecía que lo habías atrapado!"))
      Battle::PokeBallEffects.onFailCatch(ball, self, battler)
    when 2
      pbDisplay(_INTL("¡Qué pena! ¡Te ha faltado poco!"))
      Battle::PokeBallEffects.onFailCatch(ball, self, battler)
    when 3
      pbDisplay(_INTL("¡Uy! ¡Casi lo consigues!"))
      Battle::PokeBallEffects.onFailCatch(ball, self, battler)
    when 4
      pbDisplayBrief(_INTL("¡Ya está! ¡{1} atrapado!", pkmn.name))
      @scene.pbThrowSuccess   # Play capture success jingle
      pbRemoveFromParty(battler.index, battler.pokemonIndex)
      # Gain Exp
      if Settings::GAIN_EXP_FOR_CAPTURE
        battler.captured = true
        pbGainExp
        battler.captured = false
      end
      battler.pbReset
      if pbAllFainted?(battler.index)
        @decision = (trainerBattle?) ? 1 : 4   # Battle ended by win/capture
      end
      # Modify the Pokémon's properties because of the capture
      if GameData::Item.get(ball).is_snag_ball?
        pkmn.owner = Pokemon::Owner.new_from_trainer(pbPlayer)
      end
      Battle::PokeBallEffects.onCatch(ball, self, pkmn)
      pkmn.poke_ball = ball
      pkmn.makeUnmega if pkmn.mega?
      pkmn.makeUnprimal
      pkmn.update_shadow_moves if pkmn.shadowPokemon?
      pkmn.record_first_moves
      # Reset form
      pkmn.forced_form = nil if MultipleForms.hasFunction?(pkmn.species, "getForm")
      @peer.pbOnLeavingBattle(self, pkmn, true, true)
      # Make the Poké Ball and data box disappear
      @scene.pbHideCaptureBall(idxBattler)
      # Save the Pokémon for storage at the end of battle
      @caughtPokemon.push(pkmn)
    end
    if numShakes != 4
      @first_poke_ball = ball if !@poke_ball_failed
      @poke_ball_failed = true
    end
  end

  #=============================================================================
  # Calculate how many shakes a thrown Poké Ball will make (4 = capture)
  #=============================================================================
  def pbCaptureCalc(pkmn, battler, catch_rate, ball)
    return 4 if $DEBUG && Input.press?(Input::CTRL)
    # Get a catch rate if one wasn't provided
    catch_rate = pkmn.species_data.catch_rate if !catch_rate
    # Modify catch_rate depending on the Poké Ball's effect
    if !pkmn.species_data.has_flag?("UltraBeast") || ball == :BEASTBALL
      catch_rate = Battle::PokeBallEffects.modifyCatchRate(ball, catch_rate, self, battler)
    else
      catch_rate /= 10
    end
    # First half of the shakes calculation
    a = battler.totalhp
    b = battler.hp
    x = (((3 * a) - (2 * b)) * catch_rate.to_f) / (3 * a)
    # Calculation modifiers
    if battler.status == :SLEEP || battler.status == :FROZEN
      x *= 2.5
    elsif battler.status != :NONE
      x *= 1.5
    end
    x = x.floor
    x = 1 if x < 1
    # Definite capture, no need to perform randomness checks
    return 4 if x >= 255 || Battle::PokeBallEffects.isUnconditional?(ball, self, battler)
    # Second half of the shakes calculation
    y = (65_536 / ((255.0 / x)**0.1875)).floor
    # Critical capture check
    if Settings::ENABLE_CRITICAL_CAPTURES
      dex_modifier = 0
      numOwned = $player.pokedex.owned_count
      if numOwned > 600
        dex_modifier = 5
      elsif numOwned > 450
        dex_modifier = 4
      elsif numOwned > 300
        dex_modifier = 3
      elsif numOwned > 150
        dex_modifier = 2
      elsif numOwned > 30
        dex_modifier = 1
      end
      dex_modifier *= 2 if $bag.has?(:CATCHINGCHARM)
      c = x * dex_modifier / 12
      # Calculate the number of shakes
      if c > 0 && pbRandom(256) < c
        @criticalCapture = true
        return 4 if pbRandom(65_536) < y
        return 0
      end
    end
    # Calculate the number of shakes
    numShakes = 0
    4.times do |i|
      break if numShakes < i
      numShakes += 1 if pbRandom(65_536) < y
    end
    return numShakes
  end
end

#===============================================================================
#
#===============================================================================
class Battle
  include Battle::CatchAndStoreMixin
end

