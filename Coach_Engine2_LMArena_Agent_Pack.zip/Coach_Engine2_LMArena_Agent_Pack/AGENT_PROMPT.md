# Pokémon Añil/Azul Competitive Coach — Agent Handoff

You are taking over an advanced Pokémon Essentials/Añil battle-coach engineering project. Work as a senior Ruby/Pokémon Essentials battle-engine engineer. The goal is not to keep stacking monkey-patches; the goal is to audit and refactor the Coach into a coherent, testable Engine 2.0 while preserving the game outside battle.

## Files in this pack
- `Scripts.rxdata`: current user build and source of truth.
- `extracted_scripts/`: all 616 scripts extracted from the current `Scripts.rxdata`, in load order.
- `SCRIPT_MANIFEST.tsv`: index/name/file map.
- `data/moves.dat`, `items.dat`, `abilities.dat`, `species.dat`: current game data.

IMPORTANT: inspect the actual files before making claims. The current uploaded build contains Coach modules through v27 (`Competitive Coach v27 Pre-Action KO Authority`); it does NOT contain the later conversational v28 patch. Do not pretend otherwise. Preserve a clean backup.

## Project history / intent
The Coach is an in-battle recommendation engine with a minimal HUD (`COACH -> action`, `ALT -> second option` / critical warning). It should maximize battle-winning prospects, not merely immediate damage. It must work for arbitrary teams and for both AI battles (e.g. Elite 4) and multiplayer using only information legitimately available to the normal client.

Existing experimental layers include: PvP Radar/live capture, Fidelity Rules, Native Rules Engine, Battle Digital Twin, 6x6 Strategic Twin, Probabilistic Solver, Battle-Isolated Initiative, and Pre-Action KO Authority. Audit all of them for duplication, shadowed aliases, contradictory scoring, stale state, hooks outside Battle, and recommendation/HUD inconsistencies.

## Non-negotiable architecture
Refactor toward modules/classes with clear ownership:
1. `BattleState` / `VirtualState`: full 6v6 state, active indices, HP/maxHP, status, stat stages, ability, item/consumption, types/forms/Mega, moves/PP where available, volatile effects, hazards/screens, weather/terrain, Trick Room/Tailwind and other field/side effects.
2. `RulesAdapter`: derives behavior from the actual Añil/Pokémon Essentials code and GameData/function codes. Avoid hard-coded Pokémon-specific rules.
3. `ActionGenerator`: legal moves, switches, deliberate sacks, Mega/form choices, etc.
4. `TurnResolver`: the ONLY authority allowed to create successor battle states.
5. `DamageAccuracyModel`: faithful damage, accuracy, immunity and modifiers using actual game rules where possible.
6. `SearchEngine`: adversarial, probabilistic, iterative deepening/alpha-beta or an appropriate expectiminimax variant, transposition table, selective/quiescence search, with a strict time budget suitable for JoiPlay/Android.
7. `Evaluator`: material, HP, win conditions, positioning, hazards, tempo, setup, endgame, preservation value.
8. `OpponentModel`: only current-battle observed/legal information; never private/unauthorized data.
9. `CoachHUD`: presentation only. It must never compute a separate contradictory tactical result.

## Correct turn semantics
A search node must represent a complete Pokémon turn, not “my move then opponent response” in a naive sequence.

Resolve joint choices in this conceptual order:
- both sides choose actions;
- switches and their entry consequences are resolved according to the real engine;
- determine effective move priority including ability/item/field/function-code conditions;
- determine order by Speed and all real modifiers, including Trick Room and ties;
- execute first action;
- immediately apply HP/status/stages/item/ability/form/field consequences;
- if the second actor fainted or can no longer act, cancel its action;
- otherwise execute the second action;
- apply end-of-turn effects;
- only then evaluate/continue search.

Priority moves must be able to KO a faster opponent before it acts. Conditional priority (e.g. Sucker Punch-like mechanics) must respect its condition rather than being treated as unconditional +priority.

## Switch semantics
Hard switching costs the turn. For every switch candidate:
- apply entry hazards and entry effects;
- resolve the opponent's chosen action against the Pokémon that actually entered;
- reject/strongly disfavor ordinary switches that are immediately KO'd by known/relevant responses;
- distinguish `SWITCH` from intentional `SACRIFICE` in both engine and HUD;
- opponent switches must be first-class actions too;
- support double-switch and revenge-kill lines naturally through the resolver/search, not hand-coded bonuses.

## Probabilities
Do not turn accuracy into “damage * accuracy” when tactical branching matters. Build chance outcomes when practical:
- hit/miss after all contextual modifiers;
- No Guard and equivalent mechanics;
- Accuracy/Evasion stages;
- abilities/items/field/weather affecting accuracy;
- damage rolls;
- critical hits;
- secondary effects;
- multi-hit distributions;
- speed ties.
Group low-impact outcomes if necessary for performance, but document approximations.

## Important systemic interactions
- Contrary + Superpower must update future Attack/Defense stages correctly and be valued in later turns.
- Setup moves such as Nasty Plot/Swords Dance/Dragon Dance/Calm Mind must modify the virtual state and future calculations, not receive only heuristic setup bonuses.
- No Guard + Thunder (or any affected move) must not retain a fake miss probability if the real game rules guarantee the hit.
- Screens, hazards, weather, terrain, Substitute, Protect, Taunt, Encore, Choice lock, recoil/drain, healing, pivoting, phazing, trapping, status and relevant custom Añil mechanics should progressively move from heuristics to rule-faithful transitions.

## Mandatory regression tests from real failures
Create automated or deterministic harnesses for at least these cases:
1. **Steelix -> Malamar switch safety**: if Steelix has a known Iron Tail (or another move) that can KO Malamar on entry, the Coach must not label `Switch -> Malamar` as a safe normal switch. If sacrificing Malamar is strategically selected, it must explicitly say `SACRIFICE` and have a justified continuation.
2. **Heracross faster than Malamar**: if Heracross acts first and can OHKO current Malamar, the Coach must not recommend `Knock Off/Desarme` based on damage/effect that Malamar will never execute. First-action KO cancels second action.
3. **Glimmora Lv100 308/308 vs Mareep Lv3 16/16**: if Glimmora has a high-confidence immediate KO and Mareep poses negligible immediate threat, do not recommend an arbitrary hard switch to Zoroark. Charge real tempo/opportunity cost for switching and preserve a safe free KO unless a concrete strategic reason dominates it.
4. **No Guard + Thunder**: contextual accuracy must become guaranteed when the actual game rules say so.
5. **Contrary + Superpower**: future virtual state must reflect the inverted stat changes and search must value the resulting snowball.
6. **NPC/map/input isolation**: outside battle, NPC interaction, map controls and normal Input must behave exactly as baseline. Coach hooks must not consume map interaction input or stall Scene_Map.

Add more tests discovered during audit.

## Audit first, implementation second
Before editing behavior:
- map the real battle call graph and relevant Battle/AI/GameData handlers;
- identify all Coach scripts and alias chains;
- identify which later patches override earlier methods;
- identify code that is dead, duplicated, contradictory, or called outside Battle;
- document which calculations are exact vs heuristic;
- inspect the `.dat` loading/structures using the game's own classes where possible;
- produce a concise `AUDIT.md` and an implementation plan.

Then implement Engine 2.0. Prefer replacing/shadowing the experimental Coach stack with one coherent module loaded at the end rather than editing unrelated vanilla scripts. Do not delete original game scripts. Keep a backup and make the new layer easy to disable.

## Performance
Target JoiPlay/Android as a constrained runtime. Use elapsed-time budgets in addition to node budgets. Cache immutable rule lookups. Keep transposition keys compact and correct. Avoid allocations/deep Marshal copies in hot loops when a structured copy-on-write state can work. Instrument nodes, depth, elapsed ms, cache hit rate and branch counts, but keep normal HUD minimal.

## Multiplayer / security boundary
Use only opponent information the normal client legitimately receives through current battle state, Team Preview or BattleSync. Do not bypass anti-cheat, debug detection, authentication, authorization, hidden server routes or private opponent data. Do not add channel scanning/flooding. Local AI battles may use information legitimately present in the local trainer battle objects, but clearly distinguish omniscient test harnesses from production Coach behavior.

## Deliverables
Produce:
- `AUDIT.md` with architecture map, concrete defects and exact/heuristic inventory;
- clean Engine 2.0 source files or a clearly isolated final patch module;
- regression tests/harness and results;
- performance benchmark notes;
- a rebuilt `Scripts.rxdata` as a NEW file, never overwriting the supplied original;
- `CHANGELOG.md` describing what changed and remaining approximations.

Validation before declaring success:
- Ruby syntax checks for new source;
- load/decompress round-trip of every `Scripts.rxdata` entry;
- verify original script count/order except intentional appended/replaced Coach entry;
- run all regression tests;
- explicitly report failures/unsupported mechanics rather than claiming perfection.

Do not invent benchmark numbers, win rates, or test passes. Inspect, implement, run, and report evidence.
