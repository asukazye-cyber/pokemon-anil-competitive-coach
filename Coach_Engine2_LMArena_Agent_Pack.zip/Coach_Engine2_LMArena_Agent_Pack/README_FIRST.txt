Open AGENT_PROMPT.md and give its full contents to the LM Arena Agent together with this project pack.
The current Scripts.rxdata has 616 entries and ends at Coach v27. Treat it as source of truth.
Ask the Agent to audit first, then implement, test, and return a NEW Scripts.rxdata plus AUDIT.md/CHANGELOG.md.
